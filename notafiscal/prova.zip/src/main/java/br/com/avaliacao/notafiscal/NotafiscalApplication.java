package br.com.avaliacao.notafiscal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotafiscalApplication {

	public static void main(String[] args) {
		SpringApplication.run(NotafiscalApplication.class, args);
	}

}

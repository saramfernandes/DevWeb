package br.com.avaliacao.notafiscal.util;

import br.com.avaliacao.notafiscal.dto.NotaFiscalDto;
import br.com.avaliacao.notafiscal.dto.ProdutoDto;

import java.util.ArrayList;
import java.util.List;

public class BancoDados {
    public static List<ProdutoDto> produtos = new ArrayList<ProdutoDto>();
    public static List<NotaFiscalDto> notaFiscais = new ArrayList<NotaFiscalDto>();
}
